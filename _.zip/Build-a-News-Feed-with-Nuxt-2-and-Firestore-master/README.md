## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/build-a-news-feed-with-nuxt-2-and-firestore-video/9781839210402)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Build-a-News-Feed-with-Nuxt-2-and-Firestore
Build a News Feed with Nuxt 2 and Firestore, published by Packt
